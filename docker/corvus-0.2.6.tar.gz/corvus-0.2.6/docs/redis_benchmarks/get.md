# Get

Command: `redis-benchmark -h 10.0.16.72 -p 8802 -n 90000000 -r 90000000 -t get -P 1000 -c 100`  
Result:

```
GET: 0.00
GET: 1137382.75
GET: 1264822.12
GET: 1304232.88
GET: 1332177.88
GET: 1347133.75
GET: 1355952.12
GET: 1360478.38
GET: 1368479.50
GET: 1371010.62
GET: 1375897.88
GET: 1376995.62
GET: 1381603.50
GET: 1380835.38
GET: 1386440.38
GET: 1386049.00
GET: 1389415.88
GET: 1391447.38
GET: 1392847.50
GET: 1391962.75
GET: 1393328.00
GET: 1394249.00
GET: 1395205.25
GET: 1396485.75
GET: 1397131.50
GET: 1397378.50
GET: 1397786.62
GET: 1398930.12
GET: 1397969.00
GET: 1399393.62
GET: 1398770.88
GET: 1400744.25
GET: 1400199.88
GET: 1399609.00
GET: 1401384.00
GET: 1400773.75
GET: 1402287.38
GET: 1401152.75
GET: 1402204.62
GET: 1402847.12
GET: 1402575.62
GET: 1403081.12
GET: 1403388.62
GET: 1403046.62
GET: 1402507.75
GET: 1402363.25
GET: 1403100.62
GET: 1402432.88
GET: 1402465.50
GET: 1402553.62
GET: 1402300.38
GET: 1402177.25
GET: 1401366.50
GET: 1402144.25
GET: 1402265.75
GET: 1402161.38
GET: 1402194.62
GET: 1403140.50
GET: 1403281.50
GET: 1402819.25
GET: 1403250.12
GET: 1403656.00
GET: 1403521.25
GET: 1403465.38
GET: 1403473.62
GET: 1404343.00
GET: 1403792.50
GET: 1404631.12
GET: 1404289.25
GET: 1404546.50
GET: 1404432.75
GET: 1404645.75
GET: 1404763.25
GET: 1404743.62
GET: 1404905.00
GET: 1405053.12
GET: 1405082.62
GET: 1405380.12
GET: 1405583.88
GET: 1405809.50
GET: 1405778.25
GET: 1405548.00
GET: 1405734.88
GET: 1405385.00
GET: 1405424.75
GET: 1406011.12
GET: 1406491.12
GET: 1407060.12
GET: 1407305.75
GET: 1407883.75
GET: 1408228.50
GET: 1408709.38
GET: 1409266.75
GET: 1409597.12
GET: 1409978.00
GET: 1410405.38
GET: 1410845.62
GET: 1411325.38
GET: 1411632.12
GET: 1412045.12
GET: 1412378.62
GET: 1412440.12
GET: 1413219.88
GET: 1413292.38
GET: 1413795.75
GET: 1414432.62
GET: 1414523.00
GET: 1414761.12
GET: 1415575.62
GET: 1415511.12
GET: 1416060.75
GET: 1416066.50
GET: 1416208.50
GET: 1416631.38
GET: 1417321.50
GET: 1417121.50
GET: 1417560.00
GET: 1417928.50
GET: 1418177.50
GET: 1418632.25
GET: 1418680.12
GET: 1418955.38
GET: 1419286.12
GET: 1419492.38
GET: 1419727.88
GET: 1419948.50
GET: 1420139.38
GET: 1420206.62
GET: 1420481.00
GET: 1420737.88
GET: 1420978.25
GET: 1421180.38
GET: 1421392.75
GET: 1421532.50
GET: 1421737.38
GET: 1422038.00
GET: 1422335.88
GET: 1422550.38
GET: 1422710.75
GET: 1422806.25
GET: 1423243.25
GET: 1423470.62
GET: 1423845.38
GET: 1423963.12
GET: 1424044.00
GET: 1424395.25
GET: 1424561.62
GET: 1424662.00
GET: 1424797.25
GET: 1424872.50
GET: 1425155.25
GET: 1425121.12
GET: 1425455.75
GET: 1425394.00
GET: 1425670.50
GET: 1425741.62
GET: 1425912.88
GET: 1426228.88
GET: 1426366.50
GET: 1426347.38
GET: 1426507.62
GET: 1426715.62
GET: 1426875.88
GET: 1426905.62
GET: 1427084.62
GET: 1427183.00
GET: 1427260.25
GET: 1427388.38
GET: 1427534.88
GET: 1427557.25
GET: 1427912.75
GET: 1427866.50
GET: 1427960.25
GET: 1428149.38
GET: 1428259.50
GET: 1428258.00
GET: 1428324.62
GET: 1428458.38
GET: 1428749.38
GET: 1428836.88
GET: 1429054.50
GET: 1428938.12
GET: 1429262.62
GET: 1429299.50
GET: 1429553.25
GET: 1429476.12
GET: 1429665.50
GET: 1429738.38
GET: 1429945.50
GET: 1430079.75
GET: 1430114.38
GET: 1430285.38
GET: 1430463.75
GET: 1430593.12
GET: 1430503.75
GET: 1430836.12
GET: 1430920.88
GET: 1430993.38
GET: 1430917.75
GET: 1431201.12
GET: 1431165.12
GET: 1431511.00
GET: 1431355.00
GET: 1431555.25
GET: 1431612.75
GET: 1431712.12
GET: 1431733.00
GET: 1431872.25
GET: 1431812.50
GET: 1432043.00
GET: 1431966.62
GET: 1432216.50
GET: 1432209.62
GET: 1432286.25
GET: 1432493.75
GET: 1432509.88
GET: 1432489.25
GET: 1432704.88
GET: 1432759.75
GET: 1432917.50
GET: 1432861.88
GET: 1433017.88
GET: 1433124.50
GET: 1433194.25
GET: 1433486.25
GET: 1433355.25
GET: 1433455.38
GET: 1433501.88
GET: 1433708.88
GET: 1433753.75
GET: 1433746.00
GET: 1433770.12
GET: 1433917.62
GET: 1433981.00
GET: 1434089.25
GET: 1434097.38
GET: 1434259.12
GET: 1434231.62
GET: 1434292.88
GET: 1434413.75
GET: 1434606.50
GET: 1434579.00
GET: 1434634.50
GET: 1434656.50
GET: 1434678.38
GET: 1434732.88
GET: 1434738.12
GET: 1434886.00
GET: 1434957.75
GET: 1435007.38
GET: 1434931.38
====== GET ======
  90000000 requests completed in 62.72 seconds
  100 parallel clients
  3 bytes payload
  keep alive: 1

0.00% <= 10 milliseconds
0.01% <= 11 milliseconds
0.02% <= 12 milliseconds
0.04% <= 13 milliseconds
0.05% <= 14 milliseconds
0.06% <= 15 milliseconds
0.08% <= 16 milliseconds
0.10% <= 17 milliseconds
0.13% <= 18 milliseconds
0.14% <= 19 milliseconds
0.16% <= 20 milliseconds
0.18% <= 21 milliseconds
0.20% <= 22 milliseconds
0.24% <= 23 milliseconds
0.29% <= 24 milliseconds
0.35% <= 25 milliseconds
0.43% <= 26 milliseconds
0.64% <= 27 milliseconds
1.12% <= 28 milliseconds
2.16% <= 29 milliseconds
4.30% <= 30 milliseconds
7.09% <= 31 milliseconds
9.94% <= 32 milliseconds
12.99% <= 33 milliseconds
15.76% <= 34 milliseconds
17.55% <= 35 milliseconds
18.63% <= 36 milliseconds
19.41% <= 37 milliseconds
20.06% <= 38 milliseconds
20.69% <= 39 milliseconds
21.39% <= 40 milliseconds
22.15% <= 41 milliseconds
23.00% <= 42 milliseconds
23.90% <= 43 milliseconds
24.95% <= 44 milliseconds
26.14% <= 45 milliseconds
27.45% <= 46 milliseconds
28.86% <= 47 milliseconds
30.32% <= 48 milliseconds
31.82% <= 49 milliseconds
33.42% <= 50 milliseconds
34.83% <= 51 milliseconds
36.11% <= 52 milliseconds
37.28% <= 53 milliseconds
38.50% <= 54 milliseconds
39.60% <= 55 milliseconds
40.72% <= 56 milliseconds
41.86% <= 57 milliseconds
43.02% <= 58 milliseconds
44.20% <= 59 milliseconds
45.36% <= 60 milliseconds
46.60% <= 61 milliseconds
47.75% <= 62 milliseconds
48.93% <= 63 milliseconds
50.18% <= 64 milliseconds
51.46% <= 65 milliseconds
52.71% <= 66 milliseconds
53.90% <= 67 milliseconds
55.14% <= 68 milliseconds
56.32% <= 69 milliseconds
57.38% <= 70 milliseconds
58.42% <= 71 milliseconds
59.51% <= 72 milliseconds
60.57% <= 73 milliseconds
61.61% <= 74 milliseconds
62.65% <= 75 milliseconds
63.66% <= 76 milliseconds
64.73% <= 77 milliseconds
65.73% <= 78 milliseconds
66.78% <= 79 milliseconds
67.83% <= 80 milliseconds
68.88% <= 81 milliseconds
69.92% <= 82 milliseconds
71.02% <= 83 milliseconds
72.04% <= 84 milliseconds
72.99% <= 85 milliseconds
73.94% <= 86 milliseconds
74.92% <= 87 milliseconds
75.84% <= 88 milliseconds
76.73% <= 89 milliseconds
77.57% <= 90 milliseconds
78.42% <= 91 milliseconds
79.24% <= 92 milliseconds
79.97% <= 93 milliseconds
80.71% <= 94 milliseconds
81.39% <= 95 milliseconds
82.03% <= 96 milliseconds
82.66% <= 97 milliseconds
83.30% <= 98 milliseconds
83.88% <= 99 milliseconds
84.55% <= 100 milliseconds
85.13% <= 101 milliseconds
85.68% <= 102 milliseconds
86.27% <= 103 milliseconds
86.83% <= 104 milliseconds
87.41% <= 105 milliseconds
87.96% <= 106 milliseconds
88.48% <= 107 milliseconds
88.99% <= 108 milliseconds
89.47% <= 109 milliseconds
89.94% <= 110 milliseconds
90.34% <= 111 milliseconds
90.76% <= 112 milliseconds
91.15% <= 113 milliseconds
91.50% <= 114 milliseconds
91.84% <= 115 milliseconds
92.13% <= 116 milliseconds
92.43% <= 117 milliseconds
92.71% <= 118 milliseconds
92.97% <= 119 milliseconds
93.19% <= 120 milliseconds
93.40% <= 121 milliseconds
93.62% <= 122 milliseconds
93.83% <= 123 milliseconds
94.04% <= 124 milliseconds
94.23% <= 125 milliseconds
94.37% <= 126 milliseconds
94.53% <= 127 milliseconds
94.67% <= 128 milliseconds
94.80% <= 129 milliseconds
94.90% <= 130 milliseconds
95.00% <= 131 milliseconds
95.10% <= 132 milliseconds
95.18% <= 133 milliseconds
95.27% <= 134 milliseconds
95.36% <= 135 milliseconds
95.42% <= 136 milliseconds
95.49% <= 137 milliseconds
95.56% <= 138 milliseconds
95.62% <= 139 milliseconds
95.69% <= 140 milliseconds
95.75% <= 141 milliseconds
95.82% <= 142 milliseconds
95.88% <= 143 milliseconds
95.95% <= 144 milliseconds
96.02% <= 145 milliseconds
96.10% <= 146 milliseconds
96.18% <= 147 milliseconds
96.27% <= 148 milliseconds
96.35% <= 149 milliseconds
96.44% <= 150 milliseconds
96.54% <= 151 milliseconds
96.62% <= 152 milliseconds
96.71% <= 153 milliseconds
96.80% <= 154 milliseconds
96.89% <= 155 milliseconds
96.97% <= 156 milliseconds
97.07% <= 157 milliseconds
97.15% <= 158 milliseconds
97.24% <= 159 milliseconds
97.33% <= 160 milliseconds
97.42% <= 161 milliseconds
97.53% <= 162 milliseconds
97.61% <= 163 milliseconds
97.71% <= 164 milliseconds
97.83% <= 165 milliseconds
97.92% <= 166 milliseconds
98.03% <= 167 milliseconds
98.12% <= 168 milliseconds
98.22% <= 169 milliseconds
98.31% <= 170 milliseconds
98.39% <= 171 milliseconds
98.48% <= 172 milliseconds
98.58% <= 173 milliseconds
98.67% <= 174 milliseconds
98.75% <= 175 milliseconds
98.85% <= 176 milliseconds
98.93% <= 177 milliseconds
98.98% <= 178 milliseconds
99.05% <= 179 milliseconds
99.11% <= 180 milliseconds
99.17% <= 181 milliseconds
99.23% <= 182 milliseconds
99.29% <= 183 milliseconds
99.34% <= 184 milliseconds
99.40% <= 185 milliseconds
99.43% <= 186 milliseconds
99.47% <= 187 milliseconds
99.50% <= 188 milliseconds
99.53% <= 189 milliseconds
99.57% <= 190 milliseconds
99.61% <= 191 milliseconds
99.64% <= 192 milliseconds
99.67% <= 193 milliseconds
99.69% <= 194 milliseconds
99.71% <= 195 milliseconds
99.72% <= 196 milliseconds
99.75% <= 197 milliseconds
99.77% <= 198 milliseconds
99.78% <= 199 milliseconds
99.80% <= 200 milliseconds
99.82% <= 201 milliseconds
99.83% <= 202 milliseconds
99.85% <= 203 milliseconds
99.86% <= 204 milliseconds
99.87% <= 205 milliseconds
99.89% <= 206 milliseconds
99.89% <= 207 milliseconds
99.91% <= 208 milliseconds
99.91% <= 209 milliseconds
99.91% <= 210 milliseconds
99.92% <= 211 milliseconds
99.93% <= 212 milliseconds
99.93% <= 213 milliseconds
99.94% <= 214 milliseconds
99.94% <= 215 milliseconds
99.95% <= 216 milliseconds
99.96% <= 217 milliseconds
99.96% <= 218 milliseconds
99.97% <= 219 milliseconds
99.97% <= 220 milliseconds
99.97% <= 221 milliseconds
99.98% <= 222 milliseconds
99.98% <= 223 milliseconds
99.98% <= 224 milliseconds
99.98% <= 226 milliseconds
99.99% <= 227 milliseconds
99.99% <= 230 milliseconds
99.99% <= 232 milliseconds
99.99% <= 233 milliseconds
99.99% <= 235 milliseconds
99.99% <= 239 milliseconds
100.00% <= 241 milliseconds
100.00% <= 242 milliseconds
100.00% <= 252 milliseconds
100.00% <= 252 milliseconds
1434994.75 requests per second
```
