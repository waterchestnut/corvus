# Set

Commands: `redis-benchmark -h 10.0.16.72 -p 8802 -n 90000000 -r 90000000 -t set -P 1000 -c 100`  
Results:

```
SET: 0.00
SET: 1167968.75
SET: 1302948.62
SET: 1344301.62
SET: 1352242.50
SET: 1375000.00
SET: 1381142.00
SET: 1390350.25
SET: 1397308.00
SET: 1398936.12
SET: 1399674.38
SET: 1403846.12
SET: 1407851.00
SET: 1408476.62
SET: 1411378.25
SET: 1411278.12
SET: 1412368.62
SET: 1413740.25
SET: 1412025.75
SET: 1413916.38
SET: 1413621.00
SET: 1414875.38
SET: 1414381.75
SET: 1413757.12
SET: 1414768.25
SET: 1415261.62
SET: 1415904.75
SET: 1415865.00
SET: 1417071.62
SET: 1417154.75
SET: 1418276.25
SET: 1418718.62
SET: 1418694.00
SET: 1418311.75
SET: 1419101.00
SET: 1419583.38
SET: 1420569.75
SET: 1420438.62
SET: 1420532.25
SET: 1420116.38
SET: 1421405.00
SET: 1420897.75
SET: 1420890.12
SET: 1421400.00
SET: 1421822.50
SET: 1422048.50
SET: 1422438.50
SET: 1422641.88
SET: 1422694.38
SET: 1422044.50
SET: 1422083.62
SET: 1423099.38
SET: 1422641.00
SET: 1423043.88
SET: 1423484.12
SET: 1423448.62
SET: 1423645.38
SET: 1423517.75
SET: 1423519.62
SET: 1423276.50
SET: 1423743.00
SET: 1423575.25
SET: 1423201.38
SET: 1423557.75
SET: 1423752.12
SET: 1423571.38
SET: 1423396.12
SET: 1423780.62
SET: 1423472.75
SET: 1423902.88
SET: 1423847.12
SET: 1424001.75
SET: 1423906.88
SET: 1424104.50
SET: 1424017.50
SET: 1424428.25
SET: 1424268.12
SET: 1424053.62
SET: 1424433.25
SET: 1424355.88
SET: 1424370.50
SET: 1424396.50
SET: 1424410.62
SET: 1424916.88
SET: 1424583.62
SET: 1424801.25
SET: 1424698.88
SET: 1425026.12
SET: 1425014.38
SET: 1425439.25
SET: 1425201.00
SET: 1425200.62
SET: 1425287.25
SET: 1425174.88
SET: 1425064.88
SET: 1425276.38
SET: 1425625.88
SET: 1425538.75
SET: 1425103.00
SET: 1425576.62
SET: 1425480.88
SET: 1425121.38
SET: 1425306.50
SET: 1425204.75
SET: 1425231.62
SET: 1425143.75
SET: 1425363.00
SET: 1425384.00
SET: 1424852.88
SET: 1425101.75
SET: 1424910.00
SET: 1425236.62
SET: 1425465.12
SET: 1425239.75
SET: 1425649.88
SET: 1425743.62
SET: 1425897.25
SET: 1425788.38
SET: 1425627.88
SET: 1425526.50
SET: 1425410.50
SET: 1425828.50
SET: 1425718.25
SET: 1425821.75
SET: 1425968.38
SET: 1425888.62
SET: 1426032.25
SET: 1425805.12
SET: 1425975.38
SET: 1425901.12
SET: 1426194.12
SET: 1426140.25
SET: 1426030.88
SET: 1426226.00
SET: 1426358.62
SET: 1426222.75
SET: 1426362.00
SET: 1426482.12
SET: 1426245.62
SET: 1426339.75
SET: 1426408.75
SET: 1426128.12
SET: 1426149.50
SET: 1426254.50
SET: 1426250.50
SET: 1426155.38
SET: 1426085.50
SET: 1426095.75
SET: 1426189.62
SET: 1426201.75
SET: 1426187.12
SET: 1426286.25
SET: 1426245.00
SET: 1426248.75
SET: 1426504.12
SET: 1426382.12
SET: 1426341.25
SET: 1426519.25
SET: 1426578.12
SET: 1426640.75
SET: 1426564.75
SET: 1426754.75
SET: 1426663.75
SET: 1426696.38
SET: 1426624.12
SET: 1426663.75
SET: 1426763.88
SET: 1426696.75
SET: 1426942.50
SET: 1426834.00
SET: 1426609.00
SET: 1426797.38
SET: 1426671.62
SET: 1426718.75
SET: 1426795.12
SET: 1426785.75
SET: 1426737.75
SET: 1426779.25
SET: 1426671.50
SET: 1426768.25
SET: 1426819.50
SET: 1426620.75
SET: 1426584.38
SET: 1426642.12
SET: 1426497.38
SET: 1426564.12
SET: 1426552.88
SET: 1426542.88
SET: 1426608.25
SET: 1426664.25
SET: 1426673.25
SET: 1426609.12
SET: 1426762.25
SET: 1426623.62
SET: 1426733.75
SET: 1426822.25
SET: 1426869.12
SET: 1426633.00
SET: 1426819.88
SET: 1426725.38
SET: 1426776.00
SET: 1426837.50
SET: 1426730.38
SET: 1426789.88
SET: 1426879.88
SET: 1426744.75
SET: 1426774.25
SET: 1426755.25
SET: 1426761.25
SET: 1426805.50
SET: 1426913.75
SET: 1426806.12
SET: 1426828.00
SET: 1426970.12
SET: 1427105.75
SET: 1426873.62
SET: 1426928.88
SET: 1427044.38
SET: 1426907.50
SET: 1426716.75
SET: 1426846.00
SET: 1426808.38
SET: 1426831.75
SET: 1426878.12
SET: 1426816.88
SET: 1426852.50
SET: 1426834.75
SET: 1426857.50
SET: 1426844.88
SET: 1426815.00
SET: 1426924.50
SET: 1426911.88
SET: 1427002.75
SET: 1427075.62
SET: 1426950.62
SET: 1426918.25
SET: 1427070.50
SET: 1427050.38
SET: 1426996.62
SET: 1426883.75
SET: 1426993.25
SET: 1427092.12
SET: 1427029.75
SET: 1426935.00
SET: 1426955.75
SET: 1427041.62
SET: 1426985.38
SET: 1427017.00
SET: 1427074.00
SET: 1427073.12
SET: 1427076.75
SET: 1427037.25
SET: 1426982.25
====== SET ======
  90000000 requests completed in 63.06 seconds
  100 parallel clients
  3 bytes payload
  keep alive: 1

0.00% <= 7 milliseconds
0.00% <= 9 milliseconds
0.01% <= 10 milliseconds
0.03% <= 11 milliseconds
0.06% <= 12 milliseconds
0.09% <= 13 milliseconds
0.13% <= 14 milliseconds
0.21% <= 15 milliseconds
0.49% <= 16 milliseconds
1.25% <= 17 milliseconds
2.42% <= 18 milliseconds
3.06% <= 19 milliseconds
3.34% <= 20 milliseconds
3.47% <= 21 milliseconds
3.55% <= 22 milliseconds
3.62% <= 23 milliseconds
3.69% <= 24 milliseconds
3.75% <= 25 milliseconds
3.82% <= 26 milliseconds
3.94% <= 27 milliseconds
4.14% <= 28 milliseconds
4.49% <= 29 milliseconds
5.03% <= 30 milliseconds
5.81% <= 31 milliseconds
6.77% <= 32 milliseconds
7.92% <= 33 milliseconds
9.22% <= 34 milliseconds
10.37% <= 35 milliseconds
11.30% <= 36 milliseconds
12.07% <= 37 milliseconds
12.80% <= 38 milliseconds
13.52% <= 39 milliseconds
14.29% <= 40 milliseconds
15.16% <= 41 milliseconds
16.17% <= 42 milliseconds
17.22% <= 43 milliseconds
18.42% <= 44 milliseconds
19.68% <= 45 milliseconds
21.04% <= 46 milliseconds
22.44% <= 47 milliseconds
23.88% <= 48 milliseconds
25.41% <= 49 milliseconds
26.83% <= 50 milliseconds
28.26% <= 51 milliseconds
29.65% <= 52 milliseconds
31.02% <= 53 milliseconds
32.34% <= 54 milliseconds
33.69% <= 55 milliseconds
34.96% <= 56 milliseconds
36.26% <= 57 milliseconds
37.62% <= 58 milliseconds
38.93% <= 59 milliseconds
40.31% <= 60 milliseconds
41.67% <= 61 milliseconds
42.98% <= 62 milliseconds
44.29% <= 63 milliseconds
45.62% <= 64 milliseconds
47.00% <= 65 milliseconds
48.36% <= 66 milliseconds
49.76% <= 67 milliseconds
51.15% <= 68 milliseconds
52.43% <= 69 milliseconds
53.78% <= 70 milliseconds
55.10% <= 71 milliseconds
56.41% <= 72 milliseconds
57.71% <= 73 milliseconds
58.98% <= 74 milliseconds
60.32% <= 75 milliseconds
61.60% <= 76 milliseconds
62.95% <= 77 milliseconds
64.19% <= 78 milliseconds
65.46% <= 79 milliseconds
66.80% <= 80 milliseconds
68.06% <= 81 milliseconds
69.31% <= 82 milliseconds
70.49% <= 83 milliseconds
71.60% <= 84 milliseconds
72.70% <= 85 milliseconds
73.85% <= 86 milliseconds
74.91% <= 87 milliseconds
75.99% <= 88 milliseconds
76.99% <= 89 milliseconds
77.97% <= 90 milliseconds
78.92% <= 91 milliseconds
79.78% <= 92 milliseconds
80.65% <= 93 milliseconds
81.43% <= 94 milliseconds
82.18% <= 95 milliseconds
82.88% <= 96 milliseconds
83.58% <= 97 milliseconds
84.25% <= 98 milliseconds
84.90% <= 99 milliseconds
85.51% <= 100 milliseconds
86.16% <= 101 milliseconds
86.72% <= 102 milliseconds
87.28% <= 103 milliseconds
87.80% <= 104 milliseconds
88.33% <= 105 milliseconds
88.85% <= 106 milliseconds
89.39% <= 107 milliseconds
89.85% <= 108 milliseconds
90.34% <= 109 milliseconds
90.82% <= 110 milliseconds
91.28% <= 111 milliseconds
91.74% <= 112 milliseconds
92.19% <= 113 milliseconds
92.56% <= 114 milliseconds
92.95% <= 115 milliseconds
93.36% <= 116 milliseconds
93.76% <= 117 milliseconds
94.14% <= 118 milliseconds
94.48% <= 119 milliseconds
94.81% <= 120 milliseconds
95.11% <= 121 milliseconds
95.42% <= 122 milliseconds
95.71% <= 123 milliseconds
95.94% <= 124 milliseconds
96.16% <= 125 milliseconds
96.40% <= 126 milliseconds
96.65% <= 127 milliseconds
96.84% <= 128 milliseconds
97.05% <= 129 milliseconds
97.25% <= 130 milliseconds
97.44% <= 131 milliseconds
97.61% <= 132 milliseconds
97.77% <= 133 milliseconds
97.94% <= 134 milliseconds
98.09% <= 135 milliseconds
98.22% <= 136 milliseconds
98.35% <= 137 milliseconds
98.46% <= 138 milliseconds
98.55% <= 139 milliseconds
98.64% <= 140 milliseconds
98.73% <= 141 milliseconds
98.82% <= 142 milliseconds
98.90% <= 143 milliseconds
98.99% <= 144 milliseconds
99.05% <= 145 milliseconds
99.12% <= 146 milliseconds
99.20% <= 147 milliseconds
99.27% <= 148 milliseconds
99.31% <= 149 milliseconds
99.36% <= 150 milliseconds
99.40% <= 151 milliseconds
99.44% <= 152 milliseconds
99.49% <= 153 milliseconds
99.54% <= 154 milliseconds
99.57% <= 155 milliseconds
99.59% <= 156 milliseconds
99.63% <= 157 milliseconds
99.67% <= 158 milliseconds
99.69% <= 159 milliseconds
99.71% <= 160 milliseconds
99.73% <= 161 milliseconds
99.75% <= 162 milliseconds
99.77% <= 163 milliseconds
99.79% <= 164 milliseconds
99.81% <= 165 milliseconds
99.83% <= 166 milliseconds
99.85% <= 167 milliseconds
99.86% <= 168 milliseconds
99.87% <= 169 milliseconds
99.88% <= 170 milliseconds
99.90% <= 171 milliseconds
99.90% <= 172 milliseconds
99.91% <= 173 milliseconds
99.91% <= 174 milliseconds
99.92% <= 175 milliseconds
99.93% <= 176 milliseconds
99.93% <= 177 milliseconds
99.93% <= 178 milliseconds
99.94% <= 179 milliseconds
99.94% <= 180 milliseconds
99.95% <= 181 milliseconds
99.95% <= 182 milliseconds
99.96% <= 183 milliseconds
99.96% <= 184 milliseconds
99.97% <= 185 milliseconds
99.97% <= 187 milliseconds
99.97% <= 188 milliseconds
99.97% <= 189 milliseconds
99.97% <= 190 milliseconds
99.98% <= 191 milliseconds
99.98% <= 192 milliseconds
99.98% <= 194 milliseconds
99.99% <= 195 milliseconds
99.99% <= 197 milliseconds
99.99% <= 200 milliseconds
99.99% <= 201 milliseconds
99.99% <= 204 milliseconds
99.99% <= 205 milliseconds
100.00% <= 206 milliseconds
100.00% <= 209 milliseconds
100.00% <= 216 milliseconds
100.00% <= 221 milliseconds
100.00% <= 221 milliseconds
1427144.25 requests per second
```
