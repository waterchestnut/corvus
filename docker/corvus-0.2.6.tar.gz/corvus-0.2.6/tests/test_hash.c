#include "test.h"
#include "hash.h"
#include "command.h"

TEST_CASE(test_hash) {
}
